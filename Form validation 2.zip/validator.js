function Validator(formSelector) {

    var formRules = {}

    /*
    Quy uoc tao rule:
    - Neu co loi thi return error message
    - Neu khong co loi thi khong tra ra gi ca (undefined)
    */
    var ValidatorRules = {
        required: function (value) {
            return value ? undefined : 'Vui long nhap truong nay'
        },

        email: function (value) {
            var regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
            return regex.test(value) ? undefined : 'Vui long nhap truong nay'
        },

        min: function (min) {
            return function (value) {
                return value.length >= min ? undefined : `Vui long nhap it nhat ${min} ky tu`
            }
        },

        max: function (max) {
            return function (value) {
                return value.length >= min ? undefined : `Vui long nhap toi da ${max} ky tu`
            }
        }
    }

    //Lay ra element trong DOM theo formSelector
    var formElement = document.querySelector(formSelector)

    //Chi xu ly khi co element trong DOM
    if (formElement) {
        var inputs = formElement.querySelectorAll('[name][rules]')

        for (var input of inputs) {
            var rules = input.getAttribute('rules').split('|')

            for (var rule of rules) {
                var ruleInfo
                var isRuleHasValue = rule.includes(':')

                if (isRuleHasValue) {
                    ruleInfo = rule.split(':')
                    rule = ruleInfo[0]
                }

                var ruleFunc = ValidatorRules[rule]

                if (isRuleHasValue) {
                    ruleFunc = ruleFunc(ruleInfo[1])
                }

                if (Array.isArray(formRules[input.name])) {
                    formRules[input.name].push(ruleFunc)
                } else {
                    formRules[input.name] = [ruleFunc]
                }
            }

            //Lang nghe su kien de validate
            input.onblur = handleValidate
        }

        //Ham thuc hien validate
        function handleValidate(event){
            var rules = formRules[event.target.name]
            var errorMessage

            rules.find(function(rule){
                errorMessage = rule(event.target.value)
                return errorMessage
            })

            //Neu co loi thi hien thi message loi ra UI
            if(errorMessage) {
                var formGroup = event.target.closest('.form-group')
                if(formGroup) {
                    var formMessage = formGroup.querySelector('.form-message')
                    if(formMessage) {
                        formMessage.innerText = errorMessage
                    }
                }
            }
        }
    }
    // console.log(formRules)
}